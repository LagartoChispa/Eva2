package com.evaii.me

import android.os.Bundle
import androidx.activity.ComponentActivity

/**
 * Actividad para la pantalla que se muestra después de que el usuario ha iniciado sesión.
 */
class LoggedInActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Se establece el layout para esta actividad, que corresponde a la pantalla de "logueado".
        setContentView(R.layout.activity_logged_in)
    }
}