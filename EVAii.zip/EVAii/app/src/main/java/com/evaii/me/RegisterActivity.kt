package com.evaii.me

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.ComponentActivity

/**
 * Actividad para la pantalla de registro de nuevos usuarios.
 */
class RegisterActivity : ComponentActivity() {

    // Almacenamiento simple en memoria para las credenciales de usuario
    companion object {
        val userList = mutableListOf<Pair<String, String>>()
    }

    private lateinit var usernameInput: EditText
    private lateinit var passwordInput: EditText
    private lateinit var confirmPasswordInput: EditText
    private lateinit var registerBtn: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Se establece el layout para esta actividad, que corresponde a la pantalla de registro.
        setContentView(R.layout.activity_register)

        usernameInput = findViewById(R.id.username_input)
        passwordInput = findViewById(R.id.password_input)
        confirmPasswordInput = findViewById(R.id.confirm_password_input)
        registerBtn = findViewById(R.id.registerBtn)

        registerBtn.setOnClickListener {
            val username = usernameInput.text.toString()
            val password = passwordInput.text.toString()
            val confirmPassword = confirmPasswordInput.text.toString()

            if (password == confirmPassword) {
                // Las contraseñas coinciden, se agrega el usuario a la lista
                userList.add(Pair(username, password))
                // Se navega de vuelta a la pantalla de inicio de sesión
                val intent = Intent(this, MainActivity::class.java)
                startActivity(intent)
                // Se finaliza esta actividad para que el usuario no pueda volver a ella con el botón de retroceso
                finish()
            } else {
                // Las contraseñas no coinciden, se muestra un mensaje de error
                Toast.makeText(this, "Las contraseñas no coinciden", Toast.LENGTH_SHORT).show()
            }
        }
    }
}