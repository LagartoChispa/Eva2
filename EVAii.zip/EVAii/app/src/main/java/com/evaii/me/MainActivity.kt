package com.evaii.me

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import androidx.activity.ComponentActivity

/**
 * Actividad principal que funciona como pantalla de inicio de sesión.
 */
class MainActivity : ComponentActivity() {

    // Declaración de variables para los elementos de la interfaz de usuario
    private lateinit var usernameInput: EditText
    private lateinit var passwordInput: EditText
    private lateinit var loginBtn: Button
    private lateinit var registerBtn: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Se establece el layout para esta actividad
        setContentView(R.layout.activity_main)

        // Inicialización de los elementos de la interfaz de usuario
        usernameInput = findViewById(R.id.username_input)
        passwordInput = findViewById(R.id.password_input)
        loginBtn = findViewById(R.id.loginBtn)
        registerBtn = findViewById(R.id.registerBtn)

        // Se configura el listener para el botón de inicio de sesión
        loginBtn.setOnClickListener {
            val username = usernameInput.text.toString()
            val password = passwordInput.text.toString()
            Log.i("Test Credentials", "Username: $username & Password: $password")
            // Simula un inicio de sesión exitoso y navega a la pantalla de "logueado"
            val intent = Intent(this, LoggedInActivity::class.java)
            startActivity(intent)
        }

        // Se configura el listener para el botón de registro
        registerBtn.setOnClickListener {
            // Navega a la pantalla de registro
            val intent = Intent(this, RegisterActivity::class.java)
            startActivity(intent)
        }
    }
}
