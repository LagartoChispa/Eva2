package cine.plus.cl.contenido;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ContenidoApplicationTests {

	@Test
	void contextLoads() {
	}

}
